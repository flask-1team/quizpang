export const CATEGORIES: string[] = [
    '프로그래밍',
    '역사',
    '상식',
    '자격증',
    '어학',
    '교과서',
    '시험 준비',
    '기타',
];
