import React, { useState, useEffect } from 'react';
import { Page, Quiz, Question } from '../types';
import Header from './components/Header';
import Footer from './components/Footer.tsx';
import HomePage from './components/HomePage.tsx';
import QuizListPage from './components/QuizListPage.tsx';
import QuizGamePage from './components/QuizGamePage.tsx';
import QuizCreationPage from './components/QuizCreationPage.tsx';
import LoginPage from './components/LoginPage.tsx';
import SignUpPage from './components/SignUpPage.tsx';
import CustomAlertModal from './components/CustomAlertModal.tsx';
import KeyFeaturesPage from './components/KeyFeaturesPage.tsx';
import QuizCategoriesPage from './components/QuizCategoriesPage.tsx';
import ProjectGoalsPage from './components/ProjectGoalsPage.tsx';
import WelcomeModal from './components/WelcomeModal.tsx';


// Mock Data
const mockQuizzes: Quiz[] = [
    { quiz_id: 1, title: 'React 기초', category: '프로그래밍', creator_id: 'Admin', votes_avg: 4.5, votes_count: 120, questions_count: 3 },
    { quiz_id: 2, title: '한국사 퀴즈', category: '역사', creator_id: 'HistoryBuff', votes_avg: 4.8, votes_count: 250, questions_count: 2 },
];

const mockQuestions: Record<number, Question[]> = {
    1: [
        { id: 101, type: 'multiple', text: 'React에서 컴포넌트의 상태를 관리하는 Hook은 무엇인가요?', options: ['useState', 'useEffect', 'useContext', 'useReducer'], correct_answer: 'useState', explanation: 'useState는 함수형 컴포넌트에서 상태(state)를 추가하고 관리할 수 있게 해주는 Hook입니다. 상태가 변경되면 컴포넌트가 다시 렌더링됩니다.', votes_avg: 4.2, votes_count: 50 },
        { id: 102, type: 'ox', text: 'React는 Angular보다 먼저 출시되었다.', correct_answer: 'X', explanation: 'AngularJS(1.0)는 2010년에, React는 2013년에 출시되었습니다. 따라서 React가 더 늦게 출시되었습니다.', votes_avg: 4.0, votes_count: 45 },
        { id: 103, type: 'subjective', text: '가상 DOM은 무엇의 약자인가요?', correct_answer: 'Virtual DOM', explanation: '가상 DOM(Virtual DOM)은 실제 DOM의 가벼운 복사본으로, UI 변경 사항을 메모리에서 계산하여 실제 DOM 조작을 최소화함으로써 성능을 향상시킵니다.', votes_avg: 4.6, votes_count: 60 },
    ],
    2: [
        { id: 201, type: 'multiple', text: '조선을 건국한 왕의 이름은 무엇인가요?', options: ['태조 이성계', '세종대왕', '궁예', '왕건'], correct_answer: '태조 이성계', explanation: '태조 이성계는 위화도 회군을 통해 고려를 무너뜨리고 1392년에 조선을 건국한 초대 왕입니다.', votes_avg: 4.9, votes_count: 120 },
        { id: 202, type: 'subjective', text: '임진왜란 당시 이순신 장군이 한산도에서 사용한 진법 이름은?', correct_answer: '학익진', explanation: '학익진은 학이 날개를 펼친 형태의 진법으로, 한산도 대첩에서 이순신 장군이 사용하여 일본 수군을 크게 물리치는 데 결정적인 역할을 했습니다.', votes_avg: 4.8, votes_count: 110 },
    ],
};


const App: React.FC = () => {
    const [page, setPage] = useState<Page>('home');
    const [activeQuizId, setActiveQuizId] = useState<number | null>(null);

    const [quizzes, setQuizzes] = useState<Quiz[]>(mockQuizzes);
    const [questions, setQuestions] = useState<Record<number, Question[]>>(mockQuestions);

    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [currentUser, setCurrentUser] = useState<string | null>(null);

    const [alert, setAlert] = useState<{ isOpen: boolean; message: string }>({ isOpen: false, message: '' });

    const [showWelcomeModal, setShowWelcomeModal] = useState(false);

    useEffect(() => {
        const hasVisited = localStorage.getItem('hasVisitedQuizPang');
        if (!hasVisited) {
            setShowWelcomeModal(true);
            localStorage.setItem('hasVisitedQuizPang', 'true');
        }
    }, []);

    const showCustomAlert = (message: string) => {
        setAlert({ isOpen: true, message });
    };

    const handleNavigate = (newPage: Page, quizId?: number) => {
        setPage(newPage);
        if (quizId) {
            setActiveQuizId(quizId);
        }
        window.scrollTo(0, 0);
    };
    
    const handleLogin = (username: string) => {
        setIsLoggedIn(true);
        setCurrentUser(username);
        showCustomAlert(`${username}님, 환영합니다!`);
        handleNavigate('home');
    };

    const handleLogout = () => {
        setIsLoggedIn(false);
        setCurrentUser(null);
        showCustomAlert('성공적으로 로그아웃되었습니다.');
        handleNavigate('home');
    };

    const handleSignUp = (username: string) => {
        // In a real app, this would involve API calls. Here, we'll just log the user in.
        handleLogin(username);
    };

    const handleSaveQuiz = (newQuiz: Quiz, newQuestions: Question[]) => {
        const updatedQuizzes = [...quizzes, newQuiz];
        const updatedQuestions = { ...questions, [newQuiz.quiz_id]: newQuestions };
        setQuizzes(updatedQuizzes);
        setQuestions(updatedQuestions);
    };
    
    const handleRateQuestion = (quizId: number, questionId: number, rating: number) => {
        const updatedQuestions = { ...questions };
        const quizQuestions = updatedQuestions[quizId];
        if (quizQuestions) {
            const questionIndex = quizQuestions.findIndex(q => q.id === questionId);
            if (questionIndex !== -1) {
                const question = quizQuestions[questionIndex];
                const newTotalScore = (question.votes_avg * question.votes_count) + rating;
                const newVotesCount = question.votes_count + 1;
                question.votes_avg = newTotalScore / newVotesCount;
                question.votes_count = newVotesCount;
                setQuestions(updatedQuestions);
            }
        }
    };

    const renderPage = () => {
        switch (page) {
            case 'quizList':
                return <QuizListPage quizzes={quizzes} questions={questions} onNavigate={handleNavigate} />;
            case 'quizGame':
                const activeQuiz = quizzes.find(q => q.quiz_id === activeQuizId);
                const activeQuestions = activeQuizId ? questions[activeQuizId] : [];
                return activeQuiz ? <QuizGamePage quiz={activeQuiz} questions={activeQuestions} onNavigate={handleNavigate} onRateQuestion={handleRateQuestion} /> : <QuizListPage quizzes={quizzes} questions={questions} onNavigate={handleNavigate} />;
            case 'quizCreation':
                return <QuizCreationPage onSaveQuiz={handleSaveQuiz} onNavigate={handleNavigate} showCustomAlert={showCustomAlert} />;
            case 'login':
                return <LoginPage onLogin={handleLogin} onNavigate={handleNavigate} showCustomAlert={showCustomAlert} />;
            case 'signup':
                return <SignUpPage onSignUp={handleSignUp} onNavigate={handleNavigate} showCustomAlert={showCustomAlert} />;
            case 'keyFeatures':
                return <KeyFeaturesPage onNavigate={handleNavigate} />;
            case 'quizCategories':
                return <QuizCategoriesPage onNavigate={handleNavigate} />;
            case 'projectGoals':
                return <ProjectGoalsPage onNavigate={handleNavigate} />;
            case 'home':
            default:
                return <HomePage onNavigate={handleNavigate} />;
        }
    };

    return (
        <div className="flex flex-col min-h-screen font-sans text-gray-800">
            <Header onNavigate={handleNavigate} isLoggedIn={isLoggedIn} currentUser={currentUser} onLogout={handleLogout} />
            <div className="flex-grow">
                {renderPage()}
            </div>
            <Footer />
            <CustomAlertModal isOpen={alert.isOpen} message={alert.message} onClose={() => setAlert({ isOpen: false, message: '' })} />
            {/* showWelcomeModal이 true일 때만 WelcomeModal을 렌더링 */}
            <WelcomeModal isOpen={showWelcomeModal} onClose={() => setShowWelcomeModal(false)} />
        </div>
    );
};

export default App;