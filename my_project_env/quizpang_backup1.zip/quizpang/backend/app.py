import os
import json
import logging
from flask import Flask, jsonify, request
from flask_cors import CORS
from google import genai
from google.genai import types
from google.genai.errors import APIError
from db import get_db_manager, db_manager # 수정: db_manager 전역 변수도 임포트하여 초기화 상태 확인 가능
from auth import auth_bp
from quiz import quiz_bp # 퀴즈 블루프린트 임포트
import atexit   # 애플리케이션 종료시 실행을 요청 (ex. DB연결 종료)
from flask_cors import CORS

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- 환경 설정 ---
# 1. Gemini API 키를 환경 변수에서 로드합니다. (필수)
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    logger.error("GEMINI_API_KEY 환경 변수가 설정되지 않았습니다. API 키를 설정해주세요.")
    # 실제 운영 환경에서는 앱을 종료해야 하지만, 개발 편의를 위해 일단 경고만 남깁니다.
    # raise EnvironmentError("GEMINI_API_KEY is not set.")

# 2. Flask 애플리케이션 초기화 및 CORS 설정
app = Flask(__name__)
# 프론트엔드(Vite 개발 서버)의 요청을 허용합니다.
CORS(app, resources={r"/*": {"origins": "http://localhost:5173"}})

# 3. Gemini 클라이언트 초기화
# quiz.py에서도 사용할 수 있도록 전역 변수로 정의합니다.
try:
    if GEMINI_API_KEY:
        client = genai.Client(api_key=GEMINI_API_KEY)
    else:
        client = None 
except Exception as e:
    logger.error(f"Gemini 클라이언트 초기화 실패: {e}")
    client = None

# 4. 데이터베이스 연결 관리자 초기화 (함수 호출을 통해 싱글톤 인스턴스 확보)
# 이 작업은 앱 시작 시 한 번만 실행됩니다.
get_db_manager()

# 5. 블루프린트 등록
app.register_blueprint(auth_bp, url_prefix='/api/auth') # 사용자 인증 (로그인/회원가입)
app.register_blueprint(quiz_bp, url_prefix='/api/quiz') # 퀴즈 생성 및 조회/투표 기능

# 6. 애플리케이션 종료 시 DB 연결 해제
# atexit.register(lambda: db_manager.close() if db_manager else None)

# --- 기본 라우트 ---

@app.route('/')
def home():
    return jsonify({"message": "Welcome to QuizPang API"})

# NOTE: 이전 app.py 스니펫에 있던 /api/vote/add와 /api/user/create 라우트는 
# 각각 quiz.py와 auth.py로 이동되었으므로 여기서 제거됩니다.

# 서버 실행
if __name__ == '__main__':
    # Flask 앱이 5001 포트에서 실행되도록 설정
    app.run(port=5001, debug=True)
