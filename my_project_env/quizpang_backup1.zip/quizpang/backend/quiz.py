import logging
import json
import os
from flask import Blueprint, jsonify, request, abort
from google import genai
from google.genai import types
from google.genai.errors import APIError
from db import get_db_manager, DBManager # DBManager 타입 힌트와 get_db_manager 함수 사용

# 블루프린트 생성
# 이 블루프린트의 모든 경로는 app.py에서 '/api' 접두사를 가집니다.
quiz_bp = Blueprint('quiz', __name__)

logger = logging.getLogger(__name__)

# Gemini 클라이언트 초기화 (app.py에서 가져와 사용)
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
client = None
try:
    if GEMINI_API_KEY:
        client = genai.Client(api_key=GEMINI_API_KEY)
    else:
        logger.warning("GEMINI_API_KEY 환경 변수가 설정되지 않아 퀴즈 생성 기능을 사용할 수 없습니다.")
except Exception as e:
    logger.error(f"Gemini 클라이언트 초기화 실패: {e}")
    client = None

# 퀴즈 생성을 위한 시스템 프롬프트
SYSTEM_INSTRUCTION = (
    "당신은 사용자 맞춤형 퀴즈 생성 AI입니다. "
    "사용자가 제공한 주제, 카테고리, 질문 수, 난이도 정보를 바탕으로 퀴즈를 생성합니다. "
    "응답은 반드시 JSON 형식으로만 제공하며, 다른 설명이나 텍스트는 일절 포함하지 않습니다."
    "JSON 스키마는 다음과 같습니다: "
    "{\"title\": \"퀴즈 제목\", \"questions\": [{\"text\": \"질문 내용\", \"type\": \"multiple|subjective|ox\", \"options\": [\"옵션1\", \"옵션2\", ...], \"correct_answer\": \"정답 내용\"}]}. "
    "객관식(multiple) 질문은 반드시 4개의 옵션을 제공해야 하며, 'type' 필드 값은 영어 소문자로만 작성합니다."
)


# --- 퀴즈 라우트 (기존 app.py의 퀴즈 관련 API를 이관) ---

@quiz_bp.route('/quizzes', methods=['GET'])
def get_quizzes():
    """모든 퀴즈 목록을 조회합니다."""
    db_manager = get_db_manager()
    if not db_manager:
        return jsonify({"error": "Database connection is not available."}), 500

    try:
        quizzes = db_manager.get_all_quizzes()
        return jsonify(quizzes), 200
    except Exception as e:
        logger.error(f"퀴즈 목록 조회 실패: {e}")
        return jsonify({"error": "Failed to fetch quizzes"}), 500

@quiz_bp.route('/quizzes', methods=['POST'])
def create_quiz():
    """사용자가 직접 퀴즈를 생성하여 저장합니다."""
    db_manager = get_db_manager()
    if not db_manager:
        return jsonify({"error": "Database connection is not available."}), 500

    try:
        data = request.get_json()
        quiz_title = data.get('title')
        category = data.get('category')
        creator_id = data.get('creator_id')
        questions_data = data.get('questions')

        if not all([quiz_title, category, creator_id, questions_data]):
            return jsonify({"error": "Missing required fields (title, category, creator_id, questions)"}), 400

        # questions_data가 유효한 JSON 문자열 형태가 아닌 경우를 대비
        if not isinstance(questions_data, list):
            return jsonify({"error": "Questions data format is invalid (must be a list)"}), 400

        quiz_id = db_manager.create_quiz_with_questions(quiz_title, category, creator_id, questions_data)

        return jsonify({"message": "Quiz created successfully", "quiz_id": quiz_id}), 201

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"퀴즈 생성 실패: {e}")
        return jsonify({"error": "Failed to create quiz"}), 500


@quiz_bp.route('/quizzes/generate', methods=['POST'])
def generate_quiz():
    """Gemini API를 사용하여 퀴즈를 생성합니다."""
    if not client:
        return jsonify({"error": "Gemini API client is not initialized."}), 503

    try:
        data = request.get_json()
        topic = data.get('topic')
        category = data.get('category')
        num_questions = data.get('num_questions', 3)
        difficulty = data.get('difficulty', '보통')
        
        if not topic:
            return jsonify({"error": "Topic is required"}), 400

        # Gemini 모델 호출을 위한 프롬프트 구성
        prompt = (
            f"주제: {topic}, 카테고리: {category}, 질문 수: {num_questions}개, 난이도: {difficulty}. "
            f"이 정보에 기반하여 {num_questions}개의 퀴즈와 정답을 생성해주세요. 객관식 질문은 4개의 옵션을 포함해야 합니다."
        )

        logger.info(f"Generating quiz with prompt: {prompt}")

        # JSON 형식 응답을 요청하는 generationConfig 설정
        generation_config = types.GenerateContentConfig(
            system_instruction=SYSTEM_INSTRUCTION,
            response_mime_type="application/json",
            response_schema={
                "type": "OBJECT",
                "properties": {
                    "title": {"type": "STRING", "description": "Quiz title"},
                    "questions": {
                        "type": "ARRAY",
                        "description": "List of questions",
                        "items": {
                            "type": "OBJECT",
                            "properties": {
                                "text": {"type": "STRING", "description": "Question text"},
                                "type": {"type": "STRING", "description": "Question type: 'multiple', 'subjective', or 'ox'"},
                                "options": {"type": "ARRAY", "items": {"type": "STRING"}, "description": "Options for 'multiple' type (max 4)."},
                                "correct_answer": {"type": "STRING", "description": "The correct answer to the question."}
                            },
                            "required": ["text", "type", "correct_answer"]
                        }
                    }
                }
            }
        )
        
        # 모델 호출 (gemini-2.5-flash-preview-05-20 사용)
        response = client.models.generate_content(
            model='gemini-2.5-flash-preview-05-20',
            contents=prompt,
            config=generation_config
        )

        # 모델 응답에서 JSON 문자열 추출 및 파싱
        response_json_str = response.candidates[0].content.parts[0].text
        quiz_data = json.loads(response_json_str)

        # 유효성 검사 (간단하게)
        if not isinstance(quiz_data.get('questions'), list) or not quiz_data.get('title'):
             raise ValueError("Generated quiz data is incomplete or invalid.")

        return jsonify(quiz_data), 200

    except APIError as e:
        logger.error(f"Gemini API 호출 실패 (APIError): {e}")
        return jsonify({"error": f"AI Quiz Generation failed: API Error ({e})"}), 500
    except json.JSONDecodeError as e:
        logger.error(f"AI 응답 JSON 파싱 실패: {e}")
        return jsonify({"error": "AI response format error. Please try again."}), 500
    except Exception as e:
        logger.error(f"퀴즈 생성 중 예상치 못한 오류 발생: {e}")
        return jsonify({"error": f"An unexpected error occurred during quiz generation: {e}"}), 500


@quiz_bp.route('/quizzes/<int:quiz_id>/questions', methods=['GET'])
def get_quiz_questions(quiz_id):
    """특정 퀴즈의 질문 목록을 조회합니다."""
    db_manager = get_db_manager()
    if not db_manager:
        return jsonify({"error": "Database connection is not available."}), 500

    try:
        questions = db_manager.get_questions_by_quiz_id(quiz_id)
        if not questions:
            # 퀴즈 ID가 유효하지 않거나 질문이 없는 경우
            quiz_exists = db_manager.get_quiz_by_id(quiz_id)
            if not quiz_exists:
                return jsonify({"error": f"Quiz with ID {quiz_id} not found."}), 404
        
        return jsonify(questions), 200
    except Exception as e:
        logger.error(f"퀴즈 ID {quiz_id} 질문 조회 실패: {e}")
        return jsonify({"error": "Failed to fetch quiz questions"}), 500

@quiz_bp.route('/quizzes/<int:quiz_id>/vote', methods=['POST'])
def add_vote(quiz_id):
    """특정 퀴즈에 평가(별점)를 추가합니다."""
    db_manager = get_db_manager()
    if not db_manager:
        return jsonify({"error": "Database connection is not available."}), 500

    try:
        data = request.get_json()
        user_id = data.get('user_id')
        rating = data.get('rating')

        if not all([user_id, rating]):
            return jsonify({"error": "Missing required fields (user_id, rating)"}), 400

        try:
            rating = int(rating)
            if not (1 <= rating <= 5):
                 raise ValueError("Rating must be between 1 and 5.")
        except ValueError:
            return jsonify({"error": "Rating must be a valid integer between 1 and 5"}), 400

        # 퀴즈 존재 여부 확인
        quiz = db_manager.get_quiz_by_id(quiz_id)
        if not quiz:
            return jsonify({"error": f"Quiz with ID {quiz_id} not found."}), 404
        
        # 평가 추가 및 평균 업데이트
        db_manager.add_quiz_vote(quiz_id, user_id, rating)

        return jsonify({"message": "Vote added successfully"}), 201

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"평가 추가 실패: {e}")
        return jsonify({"error": "Failed to add vote"}), 500
