import os
import logging
import json
from dotenv import load_dotenv
import pymysql
from pymysql.cursors import DictCursor
from datetime import datetime
import random

# .env 파일에서 환경 변수 로드
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DBManager:
    """
    MariaDB 연결 풀을 관리하고 쿼리를 실행하는 클래스.
    환경 변수(.env 파일)에서 DB 연결 정보를 로드합니다.
    """
    def __init__(self):
        # 환경 변수에서 DB 연결 정보 로드
        self.DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
        self.DB_USER = os.getenv("DB_USER", "root")
        self.DB_PASSWORD = os.getenv("DB_PASSWORD", "1111")
        self.DB_NAME = os.getenv("DB_NAME", "quizpang")
        self.DB_PORT = int(os.getenv("DB_PORT", 3306))

        self.conn = None
        # 데이터베이스 연결 및 테이블 초기화
        self._initialize_database()

    def _get_connection(self):
        """데이터베이스 연결을 반환합니다."""
        if self.conn and self.conn.open:
            return self.conn
        
        try:
            self.conn = pymysql.connect(
                host=self.DB_HOST,
                user=self.DB_USER,
                password=self.DB_PASSWORD,
                database=self.DB_NAME,
                port=self.DB_PORT,
                cursorclass=DictCursor # 딕셔너리 형태로 결과를 받기 위해 설정
            )
            return self.conn
        except pymysql.Error as e:
            logger.error(f"데이터베이스 연결 실패: {e}")
            raise

    def _initialize_database(self):
        """
        데이터베이스 스키마를 초기화합니다.
        users, quizzes, questions, votes 테이블이 존재하지 않으면 생성합니다.
        """
        conn = None
        try:
            conn = self._get_connection()
            with conn.cursor() as cursor:
                # 1. users 테이블
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS users (
                        id INT NOT NULL AUTO_INCREMENT,
                        username VARCHAR(255) NOT NULL UNIQUE,
                        email VARCHAR(255) NOT NULL UNIQUE,
                        password_hash VARCHAR(255) NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (id)
                    )
                """)
                # 2. quizzes 테이블
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS quizzes (
                        id INT NOT NULL AUTO_INCREMENT,
                        title VARCHAR(255) NOT NULL,
                        category VARCHAR(100) NOT NULL,
                        creator_id INT NOT NULL,
                        votes_avg DECIMAL(3, 2) DEFAULT 0.00,
                        votes_count INT DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (id),
                        FOREIGN KEY (creator_id) REFERENCES users(id)
                    )
                """)
                # 3. questions 테이블
                # options 필드는 JSON 형식의 문자열로 저장
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS questions (
                        id INT NOT NULL AUTO_INCREMENT,
                        quiz_id INT NOT NULL,
                        type VARCHAR(20) NOT NULL, -- 'multiple', 'subjective', 'ox'
                        text TEXT NOT NULL,
                        options TEXT, -- JSON string of options for 'multiple'
                        correct_answer TEXT NOT NULL,
                        image_url VARCHAR(255),
                        explanation TEXT,
                        PRIMARY KEY (id),
                        FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
                    )
                """)
                # 4. votes 테이블 (퀴즈 평가)
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS votes (
                        quiz_id INT NOT NULL,
                        user_id INT NOT NULL,
                        rating INT NOT NULL, -- 1 to 5
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (quiz_id, user_id),
                        FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users(id)
                    )
                """)
                conn.commit()
            logger.info("데이터베이스 및 테이블 초기화 완료.")
        except pymysql.Error as e:
            logger.error(f"데이터베이스 초기화 중 오류 발생: {e}")
            if conn:
                conn.rollback()
            raise


    # --- CRUD 및 기타 DB 로직 ---

    # --- User Functions ---
    def create_user(self, username, email, password_hash):
        """새 사용자를 생성하고 ID를 반환합니다. 이메일이 이미 존재하면 ValueError를 발생시킵니다."""
        try:
            sql = "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)"
            # INSERT 쿼리 실행
            self.execute_non_query(sql, (username, email, password_hash))
            
            # 마지막으로 삽입된 ID를 가져옵니다.
            conn = self._get_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT LAST_INSERT_ID()")
                user_id = cursor.fetchone()['LAST_INSERT_ID()']
            return user_id
        except pymysql.err.IntegrityError as e:
            if 'email' in str(e):
                raise ValueError("Email already exists.")
            if 'username' in str(e):
                raise ValueError("Username already exists.")
            raise

    def get_user_by_email(self, email):
        """이메일을 통해 사용자 정보를 조회합니다."""
        sql = "SELECT id, username, email, password_hash FROM users WHERE email = %s"
        return self.execute_query(sql, (email,), fetchone=True)

    # --- Quiz Functions ---
    def get_all_quizzes(self):
        """
        모든 퀴즈 목록을 조회하고 각 퀴즈의 질문 개수를 포함합니다.
        JOIN과 GROUP BY를 사용하여 퀴즈 데이터와 질문 개수를 한번에 가져옵니다.
        """
        sql = """
        SELECT 
            q.id AS quiz_id, 
            q.title, 
            q.category, 
            q.creator_id, 
            q.votes_avg,
            q.votes_count,
            COUNT(ques.id) AS questions_count
        FROM quizzes q
        LEFT JOIN questions ques ON q.id = ques.quiz_id
        GROUP BY q.id
        ORDER BY q.created_at DESC;
        """
        return self.execute_query(sql)

    def get_quiz_by_id(self, quiz_id):
        """특정 퀴즈 정보를 조회합니다."""
        sql = "SELECT id AS quiz_id, title, category, creator_id, votes_avg, votes_count FROM quizzes WHERE id = %s"
        return self.execute_query(sql, (quiz_id,), fetchone=True)
    
    def get_questions_by_quiz_id(self, quiz_id):
        """
        특정 퀴즈의 모든 질문 목록을 조회합니다.
        options 필드는 JSON 문자열로 저장되어 있으므로, 파이썬 객체로 변환하여 반환합니다.
        """
        sql = "SELECT id, quiz_id, type, text, options, correct_answer, image_url, explanation FROM questions WHERE quiz_id = %s"
        questions = self.execute_query(sql, (quiz_id,))
        
        # options 필드를 JSON 문자열에서 Python 리스트/딕셔너리로 변환
        for q in questions:
            if q.get('options'):
                try:
                    # options가 JSON 문자열인 경우 파싱
                    q['options'] = json.loads(q['options'])
                except json.JSONDecodeError:
                    # 파싱 오류 시 (잘못된 데이터)
                    logger.warning(f"Question ID {q['id']} options field is not valid JSON.")
                    q['options'] = []
            else:
                q['options'] = []

        return questions

    def create_quiz_with_questions(self, title, category, creator_id, questions_data):
        """퀴즈와 해당 퀴즈의 질문들을 하나의 트랜잭션으로 생성합니다."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cursor:
                # 1. 퀴즈 생성
                quiz_sql = "INSERT INTO quizzes (title, category, creator_id) VALUES (%s, %s, %s)"
                cursor.execute(quiz_sql, (title, category, creator_id))
                quiz_id = cursor.lastrowid # 삽입된 퀴즈 ID 가져오기

                # 2. 질문들 생성
                question_sql = """
                    INSERT INTO questions 
                    (quiz_id, type, text, options, correct_answer, image_url, explanation) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                for q in questions_data:
                    # options 리스트를 JSON 문자열로 직렬화
                    options_json = json.dumps(q.get('options', []))
                    
                    cursor.execute(question_sql, (
                        quiz_id, 
                        q['type'], 
                        q['text'], 
                        options_json,
                        q['correct_answer'], 
                        q.get('image_url'),
                        q.get('explanation')
                    ))
                
                conn.commit()
                return quiz_id
        except Exception as e:
            logger.error(f"퀴즈 및 질문 생성 트랜잭션 실패: {e}")
            conn.rollback()
            raise

    # --- Voting Functions ---
    def add_quiz_vote(self, quiz_id, user_id, rating):
        """퀴즈에 평가(별점)를 추가/업데이트하고 퀴즈의 평균 점수와 투표 수를 업데이트합니다."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cursor:
                # 1. votes 테이블에 평가 추가 또는 업데이트
                # REPLACE INTO는 기존 레코드가 있으면 삭제 후 삽입, 없으면 삽입합니다. (MySQL/MariaDB에서 사용 가능)
                vote_sql = """
                REPLACE INTO votes (quiz_id, user_id, rating) 
                VALUES (%s, %s, %s);
                """
                cursor.execute(vote_sql, (quiz_id, user_id, rating))
                
                # 2. 퀴즈 테이블의 votes_avg와 votes_count 업데이트
                update_sql = """
                UPDATE quizzes 
                SET 
                    votes_count = (SELECT COUNT(*) FROM votes WHERE quiz_id = %s),
                    votes_avg = (SELECT AVG(rating) FROM votes WHERE quiz_id = %s)
                WHERE id = %s;
                """
                cursor.execute(update_sql, (quiz_id, quiz_id, quiz_id))
                
                conn.commit()

        except pymysql.Error as e:
            logger.error(f"평가 추가/업데이트 트랜잭션 실패: {e}")
            conn.rollback()
            raise
        
    def execute_query(self, sql, args=None, fetchone=False):
        """SELECT 쿼리를 실행하고 결과를 반환합니다."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, args)
                if fetchone:
                    return cursor.fetchone()
                return cursor.fetchall()
        except pymysql.Error as e:
            logger.error(f"쿼리 실행 오류: {sql} - {e}")
            raise
        
    def execute_non_query(self, sql, args=None):
        """INSERT, UPDATE, DELETE 쿼리를 실행하고 변경된 행 수를 반환합니다."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, args)
                conn.commit()
                return cursor.rowcount
        except pymysql.Error as e:
            logger.error(f"트랜잭션 실행 오류: {sql} - {e}")
            conn.rollback()
            raise
            
    def close(self):
        """연결을 닫습니다."""
        if self.conn:
            self.conn.close()
            logger.info("MariaDB 연결 해제.")


# 싱글톤 패턴을 위한 전역 변수
db_manager = None

def get_db_manager():
    """DBManager의 싱글톤 인스턴스를 반환합니다."""
    global db_manager
    if db_manager is None:
        try:
            db_manager = DBManager()
        except Exception as e:
            logger.error(f"DBManager 초기화 실패: {e}")
            db_manager = None # 초기화 실패 시 None 유지
    return db_manager
